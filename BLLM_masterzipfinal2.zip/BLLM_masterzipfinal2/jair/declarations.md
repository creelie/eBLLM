# Declarations

**Title.** BLLM: Beyond the LLM with Deep Human-Mind-AI

**Authors.** Deep Bhattacharjee (corresponding author) and Ushashi Bhattacharya.

- Deep Bhattacharjee
  - ORCID: 0000-0003-0466-750X
  - Email: itsdeep@live.com; second address d.bhattacharjee@erl-forschung.de
  - Affiliations: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India
- Ushashi Bhattacharya
  - ORCID: 0009-0002-2254-3914
  - Email: rai.bhattacharya.in@gmail.com
  - Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan

**Funding.** None.

**Competing interests.** None.

**Use of AI assistance.** Deep Bhattacharjee carried out the computations and the Lean, C, C++, Python and shell verifications with the help of AI assistance (Claude, Anthropic).

- No AI system is an author of the manuscript.
- No AI system is cited as a source.
- Every theorem stated in the manuscript has a proof in the text or in its appendices.
- The finite inequalities are also checked in Lean 4, with Mathlib and only the standard axioms.

**Data and code availability.** Everything the paper uses is in the repository https://github.com/creelie/eBLLM. It is released as version 3.1.0 of the package of the engine Anaxia and archived at Zenodo under doi:10.5281/zenodo.23484160 (all versions doi:10.5281/zenodo.23286641). The computations over the Kreuzer–Skarke list behind the seed bound are archived with the seed paper, doi:10.5281/zenodo.23483443.

The repository contains:

- the LaTeX source of the paper;
- the figure programs and their data;
- the Lean 4 development;
- the numerical checks;
- the benchmark logs;
- construction mode and the layer-tower bench;
- the per-round records of the Hodge round;
- the learn-from-failure loop with its rule book, its log and its screens;
- the reflexive polytopes and descents of the seed benchmark;
- the registry of sources.

All of it is under the MIT license. A container image of the engine is published as ghcr.io/creelie/bllm-engine; it contains no model weights.

**Author contributions.** Both authors approved the final version.

**Ethics.** The work involves no human subjects, no personal data and no animal experiments.

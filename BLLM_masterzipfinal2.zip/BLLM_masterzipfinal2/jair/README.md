# JAIR submission: BLLM: Beyond the LLM with Deep Human-Mind-AI

The suggested journal is the Journal of Artificial Intelligence Research (JAIR, https://www.jair.org). JAIR has no page limit and is open access with no fee to authors, and its reproducibility checklist matches what the paper already provides: code, Lean proofs, seeds and hardware.

| File | What it is |
|---|---|
| `BLLM_JAIR.pdf` | The manuscript in the JAIR template (review mode, with line numbers). |
| `BLLM_JAIR-source.zip` | Its source, with `jair.cls` and `acmart.cls` from the JAIR author kit. It builds on TeX Live 2026 with `latexmk -pdf main_jair.tex`, or with `pdflatex main_jair.tex` run three times; no BibTeX pass and no shell escape are needed. |
| `cover_letter.md` | A short cover letter to the Editor-in-Chief. |
| `comments_answers.md` | The answers to the three questions of the comments field, each under 150 words. |
| `checklist.md` | The filled reproducibility checklist. The same answers are the last appendix of the manuscript. |
| `declarations.md` | Authors, ORCIDs, funding (none), competing interests (none), the AI-assistance statement and data availability. |

## Before you press submit

1. **Hexagon and JAIR at the same time.** JAIR does not accept papers that are under review at another journal; preprints are allowed.
   - If you post this version on Hexagon as a preprint, add its identifier to answer 3 of `comments_answers.md`.
   - If Hexagon counts as a journal submission for you, submit to only one of the two.
2. **The version DOI.** The manuscript cites the version DOI of release 3.0.0 of eBLLM, doi:10.5281/zenodo.23464390.
3. **The bibliography.** The manuscript uses a numeric reference list typed in the source. JAIR's final style is author-year with biblatex, so the editors may ask for a `.bib` file at acceptance. The reference list is complete and every entry was checked online, so the conversion is mechanical.
4. **Fonts.** The JAIR class needs the Libertine, Inconsolata, newtx, txfonts and ccicons fonts. They are standard in TeX Live 2025 and later.

## How to submit

Submit at https://www.jair.org: register, choose "Make a submission", and upload `BLLM_JAIR.pdf` as the manuscript. Paste the three answers into the comments field, and the cover letter into the letter field if the form has one. The checklist is already inside the PDF.

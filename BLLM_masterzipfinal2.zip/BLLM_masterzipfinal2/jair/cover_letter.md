To the Editor-in-Chief, Journal of Artificial Intelligence Research

Dear Editor,

We submit our manuscript "BLLM: Beyond the LLM with Deep Human-Mind-AI" for consideration as a research article in the Journal of Artificial Intelligence Research.

A self-improving system keeps a change when a check passes, and every wrong change it keeps stays in it. The manuscript asks what it costs to keep the expected number of wrong changes below a fixed bound.

In a model where each check has perfect completeness and soundness ε per independent run, we prove five results:

- the least cost is an entropy of the cost profile, attained by a Huffman schedule, and polynomial checks replace it by a Rényi entropy;
- an infinite self-improvement can be made sound at finite cost exactly when one entropy series converges;
- a proposer needs at least e^{H_{1/2}(π)} proposals;
- n verified layers sharing one budget cost at least n log(n/θ);
- the finite inequalities behind these statements are proved in Lean 4.

We then test an engine built on these laws, Anaxia, against measurements:

- human authors come within 8% of the proposer bound, while nine language models are 1.51 to 4.28 times above it;
- memory halves the checks needed to reach what the libraries of the engine reach;
- from the rules of Steinberg's problem alone, construction mode rebuilds the gadgets of the 2016 counterexample and the counterexample itself;
- the engine learns from its failures: each failed attempt changes one of its rules, and the log of 73 attempts on 25 targets shows which changes led to a closure;
- it reached a proof of a conjecture on the reflexive 4-polytopes behind Calabi–Yau threefolds: each of the 473,800,776 polytopes of the Kreuzer–Skarke list reaches a seed in at most 348 steps.

None of the five open problems used as benchmarks is solved, and the manuscript says so in each place where it reports on them.

The work is new and its own; no part of it has been published in a journal or conference. An earlier version is archived with the software on Zenodo. The code, the Lean developments and every measurement are public under the MIT license. The reproducibility checklist is the last appendix of the manuscript.

Neither author has a competing interest, and the work received no funding. The data availability section states that the computations and verifications were carried out with AI assistance (Claude, Anthropic). No AI system is an author or is cited as a source.

Deep Bhattacharjee is the corresponding author (itsdeep@live.com).

Yours sincerely,

Deep Bhattacharjee, ORCID 0000-0003-0466-750X
Ushashi Bhattacharya, ORCID 0009-0002-2254-3914

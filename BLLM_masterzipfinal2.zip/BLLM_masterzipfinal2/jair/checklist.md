# Reproducibility checklist for JAIR

The same answers are the last appendix of the manuscript (`sections/appJ_checklist.tex`).

## All articles

- All claims investigated in this work are clearly stated. **Yes.**
- Clear explanations are given how the work reported substantiates the claims. **Yes.**
- Limitations or technical assumptions are stated clearly and explicitly. **Yes.**
- Conceptual outlines and/or pseudo-code descriptions of the AI methods introduced in this work are provided, and important implementation details are discussed. **Yes.**
- Motivation is provided for all design choices, including algorithms, implementation choices, parameters, data sets and experimental protocols beyond metrics. **Partially.**

## Articles containing theoretical contributions

Does this paper make theoretical contributions? **Yes.**

- All assumptions and restrictions are stated clearly and formally. **Yes.**
- All novel claims are stated formally (e.g., in theorem statements). **Yes.**
- Proofs of all non-trivial claims are provided in sufficient detail to permit verification by readers with a reasonable degree of expertise. **Yes.**
- Complex formalism, such as definitions or proofs, is motivated and explained clearly. **Yes.**
- The use of mathematical notation and formalism serves the purpose of enhancing clarity and precision. **Yes.**
- Appropriate citations are given for all non-trivial theoretical tools and techniques. **Yes.**

## Articles reporting on computational experiments

Does this paper include computational experiments? **Yes.**

- All source code required for conducting experiments is included in an online appendix or will be made publicly available upon publication of the paper. **Yes.**
- The source code comes with a license that allows free usage for reproducibility purposes. **Yes.**
- The source code comes with a license that allows free usage for research purposes in general. **Yes.**
- Raw, unaggregated data from all experiments is included in an online appendix or will be made publicly available upon publication of the paper. **Partially.**
- The unaggregated data comes with a license that allows free usage for reproducibility purposes. **Yes.**
- The unaggregated data comes with a license that allows free usage for research purposes in general. **Yes.**
- If an algorithm depends on randomness, then the method used for generating random numbers and for setting seeds is described in a way sufficient to allow replication of results. **Yes.**
- The execution environment for experiments is described. **Yes.**
- The evaluation metrics used in experiments are clearly explained and their choice is explicitly motivated. **Yes.**
- The number of algorithm runs used to compute each result is reported. **Yes.**
- Reported results have not been "cherry-picked" by silently ignoring unsuccessful or unsatisfactory experiments. **Yes.**
- Analysis of results goes beyond single-dimensional summaries of performance to include measures of variation, confidence, or other distributional information. **Yes.**
- All (hyper-)parameter settings for the algorithms and methods used in experiments have been reported, along with the rationale or method for determining them. **Partially.**
- The number and range of (hyper-)parameter settings explored prior to conducting final experiments have been indicated, along with the effort spent on (hyper-)parameter optimisation. **Partially.**
- Appropriately chosen statistical hypothesis tests are used to establish statistical significance in the presence of noise effects. **No.**

## Articles using data sets

Does this work rely on one or more data sets? **Yes.**

- All newly introduced data sets are included in an online appendix or will be made publicly available upon publication of the paper. **Partially.**
- The newly introduced data set comes with a license that allows free usage for reproducibility purposes. **Yes.**
- The newly introduced data set comes with a license that allows free usage for research purposes in general. **Yes.**
- All data sets drawn from the literature or other public sources are accompanied by appropriate citations. **Yes.**
- All data sets drawn from the existing literature are publicly available. **Yes.**
- All new data sets and data sets that are not publicly available are described in detail. **Yes.**
- All methods used for preprocessing, augmenting, batching or splitting data sets are described in detail. **Not applicable.**

## Explanations

The code, the Lean developments, the libraries of constructions, the task suite and the per-round records are in the archive of the software (github.com/creelie/eBLLM, Zenodo) under the MIT license. The records of the twelve Hodge rounds are archived as per-round summaries; the memory store of that run, 372 MB of channel records, is not, and the summaries keep every committed check with its outcome. The budgets of every study are stated with the study, and the steady and burst settings of the Hodge run are the only two settings of that run; the budgets were fixed by the time available on the machine of the hardware appendix, not tuned. Variation is reported as standard deviations over runs (the table of crossing-network arms), and the tower bench reports for every configuration the seeds that reached the goal and the median and range of the checks spent (the tower-bench section); no hypothesis test is used, and every comparison in the text is stated with its number of runs. The data sets drawn from the literature are the published profile of research opportunities of Chen et al. (2026) and the sources listed in the sources appendix, each cited where it is used.

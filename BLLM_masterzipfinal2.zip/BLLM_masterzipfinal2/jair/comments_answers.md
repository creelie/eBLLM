# Answers for the comments field of the JAIR submission form

JAIR asks three questions, each to be answered in at most 150 words.

## 1. Why should this work matter to AI researchers, and how could they use it?

Every self-improving system spends verification to stay correct. A code agent keeps a patch when the tests pass, and a prover keeps a lemma when a checker accepts it. The paper gives the exact price of that spending in a model with independent check runs. The price is an entropy of the cost profile, attained by a Huffman-type schedule. It also gives the least number of proposals any proposer needs, which is a Rényi entropy, and the cost of stacking verified layers.

Researchers can use these formulas in three ways:

- to set check budgets for a target rate of false acceptances;
- to compare a proposer with the bound (nine language models measure at 1.51 to 4.28 times it);
- to see when extra depth stops paying.

The engine, Anaxia, is released under the MIT license with its task suites, Lean proofs and measurements, so every experiment can be rerun.

(148 words)

## 2. Which one to three JAIR papers are most closely related, and how does this work differ?

1. Bradford et al., "Automated Conjecturing II: Chomp and Reasoned Game Play", JAIR 68 (2020), 447–461, doi:10.1613/jair.1.12188. Its conjectures are refuted by counterexamples and then refined. Our construction mode works the other way round: it outputs objects together with a certificate of what they force, and we price the checks that decide what is kept.
2. Seipp and Helmert, "Counterexample-Guided Cartesian Abstraction Refinement for Classical Planning", JAIR 62 (2018), 535–577, doi:10.1613/jair.1.11217. Our exists-forall search for gadgets is a counterexample-guided loop of the same kind. We apply it to graph construction and encode planarity by book embeddings.
3. Cropper and Dumančić, "Inductive Logic Programming at 30: A New Introduction", JAIR 74 (2022), 765–850, doi:10.1613/jair.1.13507. It learns programs from examples under a checker. We add an exact account of what checking costs and of how far a proposer is from the least number of proposals.

(143 words)

## 3. Has this work been published before, or is it under review elsewhere?

The paper has not been published in a journal or conference. An earlier version, with a different title and without construction mode, the layer towers or the Hodge round, is archived with the software on Zenodo (doi:10.5281/zenodo.23456196). This version is archived with release 3.0.0 of the software (doi:10.5281/zenodo.23464390).

[Before submitting, add one sentence on Hexagon if this version has been posted or submitted there; see README.md.]

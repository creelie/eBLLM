# Hexagon submission fields

Title: BLLM: Beyond the LLM with Deep Human-Mind-AI

Abstract: Certifying self-modifications of total cost $A$ so that at most $\theta$ false acceptances are expected costs $(A/\log\varepsilon^{-1})(H(p)+\log\theta^{-1})$ up to $A$; a sound infinite self-improvement of finite cost exists exactly when $\sum_{n}a_{n}\log(1/a_{n})$ converges; a proposer needs $e^{H_{1/2}(\pi)}$ proposals, which human authors nearly attain and language models miss by factors $1.5$ to $4.3$; and $n$ verified layers sharing that budget cost at least $n\log(n/\theta)$. Anaxia, an engine built on these laws, rebuilds from its rules the gadgets of the 2016 counterexample to Steinberg's conjecture, and solves none of five open problems.

Primary subject: cs.AI (Artificial Intelligence)
Cross-list subjects: cs.IT (Information Theory); cs.LG (Machine Learning); math.PR (Probability)
Tags: recursive self-improvement, verification, entropy, automated discovery
MSC2020: 68T05; 68T20; 94A17; 60J80; 05C15

Contributor 1 (submitting, corresponding author): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India; itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de)
Contributor 2: Ushashi Bhattacharya; ORCID 0009-0002-2254-3914; affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan; rai.bhattacharya.in@gmail.com
(No AI system is listed as a contributor.)

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: "Some parts, but not all" (change to "All parts" only after both authors have read every proof).

Provenance statement: The proofs, the text, the figures, the Lean 4 formalization, the engine Anaxia and its benchmarks, and the C, C++, Julia, Python and shell programs were carried out by Deep Bhattacharjee with the help of AI assistance (Claude, Anthropic) in the Claude Code environment. In a model with independent runs, perfect completeness and schedules fixed in advance, the paper proves that the least cost of a sound schedule of randomized checks is an entropy (Theorem A), that Kraft vectors and Huffman codes give the exact optimum (Theorem B), that Renyi entropies govern checks of polynomial order (Theorem C), that a singular chain can be sound exactly when the entropy series of its check costs converges (Theorem D), that a branching takeoff needs linearly growing check strength (Theorem E), the chain law (Theorem F), the online law (Theorem G), the laws of subagents and cascades (Theorems H and XI.1), the gap law (Theorem I: a proposer needs at least exp(H_{1/2}(pi)) proposals), and the tower law (Theorem XIV.1: n verified layers sharing one budget theta cost at least n log(n/theta), and past a finite depth every tower costs more than any fixed amount). The experiments measure the engine Anaxia, a typed crossing network with shared memory, on five open problems: typed crossing reproduces a lattice mass gap for SU(2) on beta_W < 1/3 (Theorem XVII.4, proved in the paper, not refereed, a strong-coupling lattice result and not the Clay problem), memory halves the checks, boosters add nothing, and none of the five problems is solved. Construction mode rebuilds from the rules of Steinberg's problem the gadgets of the 2016 counterexample of Cohen-Addad, Hebdige, Kral', Li and Salgado and the counterexample itself; these are rediscoveries of a published construction. At equal budgets of exact checks a second layer of builders, whose curriculum turns an easier gadget into a lemma, reaches the second gadget where the builder alone never does, and a third layer adds nothing; nothing is found on Erdos's question for cycles of length 4 to 6. Twelve rounds on the Hodge conjecture alone leave every gap where it was. Lemma XVII.1 and Theorem XVII.2 give the exact values of f(n) for Erdos problem 1183 for n <= 20, with f(20) = 12; the lower bound at n = 20 is Theorem 7.6 of the fifth version of Bhattacharjee, Mandal and Bhattacharya (doi:10.5281/zenodo.23374973), whose proof ends in a finite check. Every finite inequality is proved in Lean 4 with Mathlib in sixty-five theorems that depend only on propext, Classical.choice and Quot.sound, with no sorry, native_decide or added axiom. The probabilistic limit theorems are proved or cited in the text and are not formalized. Independent Python, C and C++ programs run 55,271 checks with no failure; no statement rests on them. Both authors approved the final version.

Tools used: Anthropic - Claude (Claude Code); Lean community - Lean 4 (v4.33.0) with Mathlib; C; C++; Julia; Python; shell.
arXiv identifier: none (not posted on arXiv).
Formalization: https://github.com/creelie/eBLLM/tree/main/paper/bllm/lean, package eBLLM and engine Anaxia, release v3.0.0, https://doi.org/10.5281/zenodo.23464390 (all versions: https://doi.org/10.5281/zenodo.23286641)

Source files or ZIP: BLLM_final2-tex.zip (the folder BLLM_final2-tex/ with main.tex, sections/ and figures/ as PNG; compiles with latexmk -pdf main.tex, no BibTeX pass, all fonts embedded). Do not upload the Lean files or the programs here.
AI provenance files: AI_PROVENANCE_BLLM.md
License: CC BY 4.0

Data availability (in the paper): the LaTeX source, the figure programs with their data, the Lean 4 formalization and the numerical checks in the folder paper/bllm of https://github.com/creelie/eBLLM, the package of the engine Anaxia, release 3.0.0, archived at Zenodo under doi:10.5281/zenodo.23464390; the compiled paper is preprintBLLM/BLLM.pdf in the same repository; the container image ghcr.io/creelie/bllm-engine holds no model weights.
AI disclosure (in the paper, Data and code availability): Deep Bhattacharjee carried out the computations and the Lean, C, C++, Python and shell verifications with the help of AI assistance (Claude, Anthropic); both authors approved the final version. No separate AI declaration.
Funding: none. Competing interests: none.
Device folder: D:\Hexagon\anaxia v1.
Upload order: BLLM_final2.pdf, BLLM_final2-tex.zip, AI_PROVENANCE_BLLM.md, HEXAGON_FORM.md. The arXiv tarball BLLM_final2-arxiv.tar.gz is for arXiv only.

BLLM master zip

BLLM: Beyond the LLM with Deep Human-Mind-AI, by Deep Bhattacharjee
(corresponding author) and Ushashi Bhattacharya.

eBLLM-v3.0.1/  the repository creelie/eBLLM at release v3.0.1: Anaxia, the
               BLLM engine (Python package eBLLM, command anaxia), its Lean 4
               library, construction mode, the layer towers and their bench,
               the sources registry, and the paper in paper/bllm (REVTeX
               source main.tex, JAIR source main_jair.tex, the figure
               programs and their data, the Lean 4 development of 65
               theorems in paper/bllm/lean, and the checks in
               paper/bllm/checks). The compiled paper is
               eBLLM-v3.0.1/preprintBLLM/BLLM.pdf.
               Zenodo: release 3.0.0 doi:10.5281/zenodo.23464390,
               release 3.0.1 doi:10.5281/zenodo.23464490,
               all versions doi:10.5281/zenodo.23286641.
               Container image: ghcr.io/creelie/bllm-engine (no model weights).
hexagon/       the Hexagon upload: BLLM_final2.pdf, BLLM_final2-tex.zip,
               AI_PROVENANCE_BLLM.md and HEXAGON_FORM.md. The arXiv tarball
               BLLM_final2-arxiv.tar.gz is in the project folder
               ai-paper/v3.0.1-hexagon.
jair/          the JAIR submission: BLLM_JAIR.pdf (review mode), its source
               BLLM_JAIR-source.zip, the cover letter, the answers for the
               comments field, the reproducibility checklist, the
               declarations, and a README with the steps to submit.

To rerun the package's checks:  cd eBLLM-v3.0.1 && bash checks/run_all.sh
To rerun the paper's checks:    cd eBLLM-v3.0.1 && bash paper/bllm/checks/run_all.sh
To rerun the tower bench:       cd eBLLM-v3.0.1 && PYTHONPATH=src python3 -m ebllm.construct.bench --jobs 3 --out tower_bench.jsonl
To build the paper:             cd eBLLM-v3.0.1/paper/bllm/paper && latexmk -pdf main.tex

None of the five benchmark problems is solved. Construction mode rebuilds a
published construction (the 2016 counterexample to Steinberg's conjecture)
and finds nothing on Erdos's question for cycles of length 4 to 6.
